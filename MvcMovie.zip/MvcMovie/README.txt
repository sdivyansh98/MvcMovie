﻿2024-05-16
Divyansh Solanki
1700 UTC

Runs the program ,confirmed the default worked
https://localhost:7239
2024-05-16
1730 UTC

 
Part 1
1730 UTC

Created a project name MVC Movies and added a controller

1745 UTC
Ran the program, Confirmed the default works:
https://localhost:7239/
Modified the index.cshtml title to MVC MOVIE by replacing the default title WELCOME
Created README.in the MVC Movies
Was able to confirm the default page

1810
I confirmed Part1 of the tutorial is complete, The started with part2

Part2 - Add a Controller

1830 UTC

Commented the default index method which is returning to class view()
Then added new index method and changed the content to "This is my default action..."
Was running when i ran the program

https://localhost:7239/Helloworld

1845  UTC
Added another method called welcome with the content of "This is the Welcome action method..."
Confirmed it was running

https://localhost:7239/Helloworld/welcome

1855 UTC

Change the Welcome method to include two parameters(name,numtimes)
Ran the program, Confirmed the changes works:

https://localhost:7239/helloworld/welcome?name=Divyansh&numTimes=6











2024-05-23
Divyansh Solanki
1531 UTC

Part 3 

Worked on Add a View and edited the Views/Shared/_Layout.cshtml then edited the  HelloWorldController file present in controller and
ran the program, was able to see the local host was able to take the command where i gave the name Divyansh and runtime 100 
and was able see my name in 100 lines respectively
https://localhost:7239/helloworld/welcome?name=Divyansh&numTimes=6


Part 4 

1545 UTC
Started adding a model for which I created a file name movie.cs in models folder and in controller Scaffold movie pages.
and created a new item with the name moviescontroller.cs

1600
Migration was done 
20240523191104_initialCreate.cs

1635 UTC
Updated the database for the testing purpose

1645 UTC
Edited the movies name with title genre price and release date

1700 UTC

Testing and was successful 
https://localhost:7239/Movies